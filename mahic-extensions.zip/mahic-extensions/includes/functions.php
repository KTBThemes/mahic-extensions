<?php

if( ! function_exists( 'is_mas_static_content_activated' ) ) {
	function is_mas_static_content_activated() {
		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
		}

		return in_array( 'mas-static-content/mas-static-content.php', $active_plugins ) || array_key_exists( 'mas-static-content/mas-static-content.php', $active_plugins );
	}
}

// Register widgets.
function mahic_extensions_widgets_register() {
    if ( class_exists( 'Mahic' ) ) {        
        include_once get_template_directory() . '/inc/widgets/class-mahic-wc-catalog-orderby.php';
        register_widget( 'mahic_WC_Catalog_Orderby' );
    }
}

add_action( 'widgets_init', 'mahic_extensions_widgets_register' );