<?php

namespace Elementor;
use Automattic\WooCommerce\Admin\Features\OnboardingTasks\Tasks\Products;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Elementor Sidebar With Products.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Mahic_Elementor_Sidebar_With_Products extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve Sidebar With Products widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'mahic_elementor_sidebar_with_products_block';
    }

    /**
     * Get widget title.
     *
     * Retrieve Sidebar With Products widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Sidebar With Products', 'mahic-extensions' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve Sidebar With Products widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-product-categories';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Sidebar With Products widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'mahic-elements' ];
    }

    /**
     * Register Sidebar With Products widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label'         => esc_html__( 'Content', 'mahic-extensions' ),
                'tab'           => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label'         => esc_html__( 'Title', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__( 'Enter title', 'mahic-extensions' ),
            ]
        );

        $this->add_control(
            'enable_sidebar',
            [
                'label'         => esc_html__('Enable Sidebar', 'mahic-extensions'),
                'type'          => Controls_Manager::SWITCHER,
                'description'   => esc_html__( 'Show sidebar block.', 'mahic-extensions' ),
                'label_on'      => esc_html__( 'Enable', 'mahic-extensions' ),
                'label_off'     => esc_html__( 'Disable', 'mahic-extensions' ),
                'return_value'  => 'true',
                'default'       => 'true',
            ]
        );

        $this->add_control(
            'sidebar_title',
            [
                'label'         => esc_html__( 'Sidebar Title', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__( 'Enter title', 'mahic-extensions' ),
            ]
        );

        $this->add_control(
            'shortcode_tag',
            [
                'label'     => esc_html__( 'Shortcode Tags', 'mahic-extensions' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'featured_products'     => esc_html__( 'Featured Products','mahic-extensions'),
                    'sale_products'         => esc_html__( 'On Sale Products','mahic-extensions'),
                    'top_rated_products'    => esc_html__( 'Top Rated Products','mahic-extensions'),
                    'recent_products'       => esc_html__( 'Recent Products','mahic-extensions'),
                    'best_selling_products' => esc_html__( 'Best Selling Products','mahic-extensions'),
                    'product_category'      => esc_html__( 'Product Category','mahic-extensions'),
                    'product_attribute'     => esc_html__( 'Product Attribute','mahic-extensions'),
                    'products'              => esc_html__( 'Products','mahic-extensions')
                ],
                'default' => 'recent_products',
            ]
        );

        $this->add_control(
            'limit',
            [
                'label'         => esc_html__('Limit', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter limit of the products.', 'mahic-extensions'),
                'default'       => 15,
            ]
        );

        $this->add_control(
            'columns',
            [
                'label'         => esc_html__('Columns', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter columns of the products.', 'mahic-extensions'),
                'default'       => 6,
            ]
        );

        $this->add_control(
            'columns_tablet',
            [
                'label'         => esc_html__('Columns Tablet', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter columns of the products in tablet view.', 'mahic-extensions'),
                'default'       => 3,
            ]
        );

        $this->add_control(
            'columns_wide',
            [
                'label'         => esc_html__('Columns Wide', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter columns of the products.', 'mahic-extensions'),
                'default'       => 5,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label'         => esc_html__( 'Orderby', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'mahic-extensions' ),
                'default'       => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label'         => esc_html__( 'Order', 'mahic-extensions' ),
                'type'          => Controls_Manager::SELECT,
                'description'   => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'mahic-extensions' ),
                'options'       => [
                        'DESC'     => esc_html__( 'DESC','mahic-extensions'),
                        'ASC'      => esc_html__( 'ASC','mahic-extensions')
                ],
                'default'       => 'ASC',
            ]
        );
        
        $this->add_control(
            'products_choice',
            [
                'label'         => esc_html__('Product Choice', 'mahic-extensions'),
                'type'          => Controls_Manager::SELECT,
                'options'       => [
                    'ids'    => esc_html__( 'IDs','mahic-extensions'),
                    'skus'   => esc_html__( 'SKUs','mahic-extensions'),
                ],
                'condition'     => [
                    'shortcode_tag' => 'products',
                ],
            ]
        );

        $this->add_control(
            'product_id',
            [
                'label'         => esc_html__( 'Product id or SKUs', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__( 'Separate multiple Product ids or SKUs by Comma ', 'mahic-extensions' ),
                'placeholder'   => esc_html__( 'Enter IDs/SKUs separate by comma(,).', 'mahic-extensions' ),
                'condition'     => [
                    'shortcode_tag' => 'products',
                ],
            ]
        );

        $this->add_control( 
            'category',
            [
                'label'         => esc_html__('Category', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter slug separate by comma(,).', 'mahic-extensions'),
                'condition'     => [
                    'shortcode_tag' => 'product_category',
                ],
            ]
        );

        $this->add_control(
            'cat_operator',
            [
                'label'         => esc_html__('Category Operator', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'mahic-extensions'),
                'default'       => 'IN',
                'condition'     => [
                    'shortcode_tag' => 'product_category',
                ],
            ]
        );

        $this->add_control(
            'attribute',
            [
                'label'         => esc_html__('Attribute', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter single attribute slug.', 'mahic-extensions'),
                'condition'     => [
                    'shortcode_tag' => 'product_attribute',
                ],
            ]
        );

        $this->add_control(
            'terms',
            [
                'label'         => esc_html__('Terms', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Enter single attribute slug.', 'mahic-extensions'),
                'condition'     => [
                    'shortcode_tag' => 'product_attribute',
                ],
            ]
        );

        $this->add_control(
            'terms_operator',
            [
                'label'         => esc_html__('Terms Operator', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'mahic-extensions'),
                'default'       => 'IN',
                'condition'     => [
                    'shortcode_tag' => 'product_attribute',
                ],
            ]
        );

        $this->add_control(
            'enable_pagination',
            [
                'label'         => esc_html__('Enable Pagination', 'mahic-extensions'),
                'type'          => Controls_Manager::SWITCHER,
                'description'   => esc_html__( 'Show pagination  block.', 'mahic-extensions' ),
                'label_on'      => esc_html__( 'Enable', 'mahic-extensions' ),
                'label_off'     => esc_html__( 'Disable', 'mahic-extensions' ),
                'return_value'  => 'true',
                'default'       => true,
            ]
        );

        $this->add_control(
            'el_class',
            [
                'label'         => esc_html__( 'Extra class name', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'placeholder'   => esc_html__( 'If you wish to style particular style use this field', 'mahic-extensions' ),
            ]
        );

        $this->end_controls_section();
    
    }

    /**
     * mahic product wrap additional classes.
     */
    public function mahic_product_wrap_additional_classes() {
        $settings = $this->get_settings_for_display();
        $tablet   = ! empty( $settings['columns_tablet'] ) ? 'row-cols-md-' . $settings['columns_tablet'] : 'row-cols-md-3';
        $classes  = array( 'products', 'list-unstyled', 'row', 'g-0', 'row-cols-2', $tablet );
        return $classes;
    }

    /**
     * Render Sidebar With Products output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings_for_display();

        extract( $settings );

        $shortcode_atts = function_exists( 'mahic_get_atts_for_shortcode' ) ? mahic_get_atts_for_shortcode( array( 'shortcode' => $shortcode_tag, 'product_category_slug' => $category, 'cat_operator' => $cat_operator, 'products_choice' => $products_choice, 'products_ids_skus' => $product_id, 'attribute' => $attribute, 'terms' => $terms, 'terms_operator' => $terms_operator ) ) : array();
        $shortcode_atts = wp_parse_args( $shortcode_atts, array( 'order' => $order, 'orderby' => $orderby,'per_page' => $limit, 'columns' => $columns, 'paginate' => $enable_pagination ) );

        if ( function_exists( 'mahic_is_wide_enabled' ) && mahic_is_wide_enabled() ) {
			$shortcode_atts[ 'columns_wide' ] = $columns_wide;
        }

        $attr = array(
			'class' => 'row categories-with-product'
		);

        if( isset( $el_class ) && !empty( $el_class ) ){
            $attr['class'] .=  ' ' . $el_class ;
        }

        if( function_exists( 'mahic_home_v10_sidebar' ) ) { ?>
            <div <?php echo mahic_render_attributes( $attr ); ?>><?php
			mahic_home_v10_sidebar( $enable_sidebar, $sidebar_title );
            if ( is_woocommerce_activated() ) : ?>
				<div class="col">
					<section class="w-100 mb-0">
						<?php if ( isset( $title ) && ! empty( $title ) ) : ?>
							<header class="mb-0">
								<h2 class="h1"><?php echo esc_html( $title ); ?></h2>
							</header>
						<?php endif; 
                        $has_product = Products::has_products();
                        if ( $has_product ) {
                            add_filter( 'mahic_product_loop_additional_classes',  array( $this, 'mahic_product_wrap_additional_classes' ) );?>
                            <?php echo mahic_do_shortcode( $shortcode_tag , $shortcode_atts ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
                            remove_filter( 'mahic_product_loop_additional_classes', array( $this, 'mahic_product_wrap_additional_classes' ) );
                        } else {
                            ?><p class="woocommerce-info mb-0"><?php esc_html_e( 'Add Products', 'mahic' ) ?></p><?php
                        }?>
					</section>
				</div>
			<?php endif; ?>
            </div><?php
		}

    }
}

Plugin::instance()->widgets_manager->register( new mahic_Elementor_Sidebar_With_Products );