<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Elementor Deals and Products Tabs Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Mahic_Elementor_Deals_And_Products_Tabs_Element extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve Deals and Products Tabs Element widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'mahic_elementor_deal_and_product_tabs';
    }

    /**
     * Get widget title.
     *
     * Retrieve Deals and Products Tabs Element Widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Deals and Products Tabs', 'mahic-extensions' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve Deals and Products Tabs Element Widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-product-tabs';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Deals and Products Tabs widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'mahic-elements' ];
    }

    /**
     * Register Deals and Products Tabs widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'mahic-extensions' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'deal_title',
            [
                'label'         => esc_html__( 'Title', 'mahic-extensions' ),
                'type'          => Controls_Manager::TEXT,
                'default'       => '',
                'placeholder'   => esc_html__( 'Enter title', 'mahic-extensions' ),
            ]
        );

        $this->add_control(
            'deal_show_savings',
            [
                'label'         => esc_html__( 'Show Savings Details', 'mahic-extensions' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'      => esc_html__( 'Enable', 'mahic-extensions' ),
                'label_off'     => esc_html__( 'Disable', 'mahic-extensions' ),
                'return_value'  => 'true',
                'default'       => 'false',
                'description'   => esc_html__( 'Deals savings text', 'mahic-extensions' ),
            ]
        );

        $this->add_control(
            'deal_savings_in',
            [
                'label'         => esc_html__( 'Savings in', 'mahic-extensions' ),
                'type'          => Controls_Manager::SELECT,
                'options' => [

                    'amount'        => esc_html__( 'Amount', 'mahic-extensions' ),
                    'percentage'    => esc_html__( 'Percentage', 'mahic-extensions' ),
                ],
                'default'=> 'amount',
            ]
        );

        $this->add_control(
            'deal_savings_text',
            [
                'label'         => esc_html__('Savings Text', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'deal_product_choice',
            [
                'label'         => esc_html__( 'Product Choice', 'mahic-extensions' ),
                'type'          => Controls_Manager::SELECT,
                'options' => [

                    'recent'    =>esc_html__( 'Recent', 'mahic-extensions' ),
                    'random'    =>esc_html__( 'Random', 'mahic-extensions' ),
                    'specific'  =>esc_html__( 'Specific', 'mahic-extensions' ),
                ],
                'default'=> 'recent',
            ]
        );


        $this->add_control(
            'deal_product_id',
            [
                'label'         => esc_html__('Product ID', 'mahic-extensions'),
                'type'          => Controls_Manager::TEXT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description'   => esc_html__('Enter title.', 'mahic-extensions'),
            ]
        );

        $repeater->add_control(
            'shortcode_tag',
            [
                'label' => esc_html__( 'Shortcode', 'mahic-extensions' ),
                'type'  => Controls_Manager::SELECT,
                'options'   => [
                    'featured_products'     => esc_html__( 'Featured Products','mahic-extensions'),
                    'sale_products'         => esc_html__( 'On Sale Products','mahic-extensions'),
                    'top_rated_products'    => esc_html__( 'Top Rated Products','mahic-extensions'),
                    'recent_products'       => esc_html__( 'Recent Products','mahic-extensions'),
                    'best_selling_products' => esc_html__( 'Best Selling Products','mahic-extensions'),
                    'product_category'      => esc_html__( 'Product Category','mahic-extensions'),
                    'products'              => esc_html__( 'Products','mahic-extensions')
                ],
                'default' => 'recent_products',
            ]
        );

        $repeater->add_control(
            'product_limit',
            [
                'label' => esc_html__( 'Limit', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description' => esc_html__( 'Enter the number of products to display.', 'mahic-extensions' ),
                'default'=> '6',
            ]
        );

        $repeater->add_control(
            'columns',
            [
                'label' => esc_html__( 'Columns', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description'   => esc_html__('Enter the number of columns to display.', 'mahic-extensions'),
                'default'=> '3',
            ]
        );

        $repeater->add_control(
            'product_limit_wide',
            [
                'label' => esc_html__( 'Wide Layout Limit', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description' => esc_html__( 'Enter the number of wide products to display.', 'mahic-extensions' ),
                'default'=> '8',
            ]
        );

        $repeater->add_control(
            'product_columns_wide',
            [
                'label' => esc_html__( 'Tab Products Wide Layout Columns', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description' => esc_html__( 'Enter the number of tap products wide layout columns to display.', 'mahic-extensions' ),
                'default'=> '4',
            ]
        );

        $repeater->add_control(
            'orderby',
            [
                'label' => esc_html__( 'Order by', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description'   => esc_html__('Enter orderby.', 'mahic-extensions'),
                'default' => 'date',
            ]
        );

        $repeater->add_control(
            'order',
            [
                'label' => esc_html__( 'Order', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description' =>esc_html__('Enter order', 'mahic-extensions' ),
                'default' => 'DESC',
            ]
        );

        $repeater->add_control(
            'products_choice',
            [
                'label' => esc_html__( 'Product Choice', 'mahic-extensions' ),
                'type'  => Controls_Manager::SELECT,
                'options'       => [
                    'ids'       =>esc_html__( 'IDs', 'mahic-extensions' ),
                    'skus'      =>esc_html__( 'SKUs', 'mahic-extensions' ),       
                ],
                'default'       =>'ids',
            ]
        );

        $repeater->add_control(
            'product_id',
            [
                'label' => esc_html__( 'Product IDs or SKUs', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description' =>esc_html__('Enter IDs/SKUs separate by comma(,).', 'mahic-extensions' ),
            ]
        );

        $repeater->add_control(
            'category',
            [
                'label' => esc_html__( 'Category', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description'   => esc_html__('Enter slug separate by comma(,).', 'mahic-extensions'),
            ]
        );

        $repeater->add_control(
            'cat_operator',
            [
                'label' => esc_html__( 'Category Operator', 'mahic-extensions' ),
                'type'  => Controls_Manager::TEXT,
                'description'   => esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'mahic-extensions'),
                'default'         => 'IN',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label'  => esc_html__( 'Products Tabs Element', 'mahic-extensions' ),
                'type'   => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render Deals and Products Tabs Block output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings();

        extract( $settings );

        if( is_object( $tabs ) || is_array( $tabs ) ) {
            $tabs = json_decode( json_encode( $tabs ), true );
        } else {
            $tabs = json_decode( urldecode( $tabs ), true );
        }

        $tabs_args = array();

        if( is_array( $tabs ) ) {
            foreach ( $tabs as $key => $tab ) {

                extract( $tab );

                if ( mahic_is_wide_enabled() ) {
                    $per_page   = $product_limit_wide;
                } else {
                    $per_page   = $product_limit;
                }
                
                $shortcode_atts = function_exists( 'mahic_get_atts_for_shortcode' ) ? mahic_get_atts_for_shortcode( array( 'shortcode' => $shortcode_tag, 'product_category_slug' => $category, 'cat_operator' => $cat_operator, 'products_choice' => $products_choice, 'products_ids_skus' => $product_id ) ) : array();
                $shortcode_atts = wp_parse_args( $shortcode_atts, array( 'order' => $order, 'orderby' => $orderby,'per_page' => $per_page, 'columns' => $columns ) );

                $tabs_args[] = array(
                    'title'             => $title,
                    'shortcode_tag'     => $shortcode_tag,
                    'atts'              => $shortcode_atts,
                );
            }
        }

        $deal_args = array(
            'is_enabled'        => 'yes',
            'section_title'     => $deal_title,
            'show_savings'      => $deal_show_savings,
            'savings_in'        => $deal_savings_in,
            'savings_text'      => $deal_savings_text,
            'product_choice'    => $deal_product_choice,
            'product_id'        => $deal_product_id,
        );

        $args = array(
            'deal_products_args'    => $deal_args,
            'product_tabs_args'     => array(
                'tabs'                  => $tabs_args,
                'columns_wide'          => $product_columns_wide,
            ),
        );

        if( function_exists( 'mahic_deal_and_tabs_block' ) ) {
            mahic_deal_and_tabs_block( $args );
        }

    }
}
Plugin::instance()->widgets_manager->register( new mahic_Elementor_Deals_And_Products_Tabs_Element );